package POJO;

public class Request_PayLoad {

	private String Transaction_ID;
	private String Transaction_Time;
	private String Note;
	
	
	public String getTransaction_ID() {
		return Transaction_ID;
	}
	public void setTransaction_ID(String transaction_ID) {
		this.Transaction_ID = transaction_ID;
	}
	public String getTransaction_Time() {
		return Transaction_Time;
	}
	public void setTransaction_Time(String transaction_Time) {
		this.Transaction_Time = transaction_Time;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		this.Note = note;
	}

	
}
